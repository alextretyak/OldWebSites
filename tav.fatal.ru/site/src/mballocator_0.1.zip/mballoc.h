extern void *MBAlloc(int size);
extern void *MBRealloc(void *p, int size);
extern int   MBMemSize(void *p);
extern void  MBFree(void *p);
extern void  MBFreeAll();
